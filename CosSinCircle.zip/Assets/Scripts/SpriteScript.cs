using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpriteScript : MonoBehaviour
{
	CosSin cosSinScript;
	int counter = 1;
	public Vector3 spritePosition = new Vector3(0f, 0f, 0f);
	public string drawType = "";
	public float speed, length, magnitude, pixelSize;
	float xPosition, colorBlue, colorRed;
	SpriteRenderer pixelSprite;

    void Start()
    {
		cosSinScript = GameObject.FindObjectOfType(typeof(CosSin)) as CosSin;
		xPosition = transform.position.x;
		pixelSprite = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
		switch (drawType)
		{	
			case "Cosinus":
				xPosition += (speed / length) * pixelSize * length;
				spritePosition.y = Mathf.Cos((xPosition) / length) * magnitude + cosSinScript.startPosition.y - 2.8f;
				colorRed = Mathf.Cos(spritePosition.y);
				colorBlue = Mathf.Cos(xPosition);
				break;
				
			case "Sinus":
				xPosition += (speed / length) * pixelSize * length;
				spritePosition.y = Mathf.Sin((xPosition) / length) * magnitude + cosSinScript.startPosition.y + 2.8f;
				colorRed = Mathf.Sin(spritePosition.y);
				colorBlue = Mathf.Sin(xPosition);
				break;
				
			case "Circle":
				float tempspritePositionX = Mathf.Cos(counter * speed) * magnitude;
				float tempspritePositionY = Mathf.Sin(counter * speed) * magnitude;
				spritePosition.x += tempspritePositionX * 0.01f;
				spritePosition.y += tempspritePositionY * 0.01f;
				colorRed = Mathf.Cos(spritePosition.y);
				colorBlue = Mathf.Sin(spritePosition.x);
				break;
			case "Spiral":
				spritePosition.x = Mathf.Cos(counter * speed * 10f) * magnitude * counter / 100f + cosSinScript.startPosition.y + 5f;
				spritePosition.y = Mathf.Sin(counter * speed * 10f) * magnitude * counter / 100f + cosSinScript.startPosition.y;
				colorRed = Mathf.Cos(counter);
				colorBlue = Mathf.Sin(counter);
				break;
		}
        transform.position = spritePosition;
		pixelSprite.color = new Color(Randomize(), colorRed, colorBlue, 1f);
		counter++;
		if (counter > 2500)
		{
			counter = 1;
		}
    }
	float Randomize()
	{
		float randomColor = Random.Range(1f, 1000f) / 1000f;
		return randomColor;
	}
}
