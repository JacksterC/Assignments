using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CosSin : MonoBehaviour
{
	
	public GameObject pixelPrefab;
	
	GameObject[] instanceOfPixel = new GameObject [7201];
	SpriteScript spriteScript;
	
	[Range(0.4f, 2)]
	public float sinusMagnitude = 1f, sinusLength = 1f, cosinusMagnitude = 1f, cosinusLength = 1f, cicleRadius = 0.5f;
	[Range(0.005f, 0.2f)]
	public float speed = 0.01f;
	[Range(2f, 20f)]
	public float setpixelSize = 2f;
	float yPosition = 0f;
	float[] xPosition = new float[4];
	int[] arrayStart = new int[4], counter = new int[4], numberOfPixels = new int[4];
	int drawType = 0, maxInstancesPerDraw = 1800;
	
	public Vector3 screenCenter, startPosition;
	
    void Start()
    {
		QualitySettings.vSyncCount = 0;
		
		screenCenter = transform.position + new Vector3(0f, 0f, 10f);
		startPosition = screenCenter + new Vector3(-8.8f, 0f, 0f);
		xPosition[0] = startPosition.x;
		xPosition[1] = startPosition.x;
		xPosition[2] = startPosition.x;
    }

    void Update()
    {
        InstantiatePixels(setpixelSize, cosinusLength, cosinusMagnitude, "Cosinus");
		InstantiatePixels(setpixelSize, sinusLength, sinusMagnitude, "Sinus");
		InstantiatePixels(setpixelSize, 3f, cicleRadius, "Circle");
		InstantiatePixels(setpixelSize, 3f, cicleRadius, "Spiral");
		
		KeyReader();
    }
	
	void InstantiatePixels(float pixelSize, float length, float magnitude, string type)
	{	
		if (counter[drawType] < maxInstancesPerDraw - 1)
		{
			switch (type)
			{	
				case "Cosinus":
					drawType = 0;
					arrayStart[drawType] = 0;
					xPosition[drawType] += (speed / length) * pixelSize * length;
					yPosition = Mathf.Cos((xPosition[drawType]) / length) * magnitude + startPosition.y - 2.8f;
					break;
					
				case "Sinus":
					drawType = 1;
					arrayStart[drawType] = maxInstancesPerDraw + 1;
					xPosition[drawType] += (speed / length) * pixelSize * length;
					yPosition = Mathf.Sin((xPosition[drawType]) / length) * magnitude + startPosition.y + 2.8f;
					break;
					
				case "Circle":
					drawType = 2;
					arrayStart[drawType] = maxInstancesPerDraw * 2 + 1;
					xPosition[drawType] = Mathf.Cos(counter[drawType]) * magnitude  + startPosition.y - 5f;
					yPosition = Mathf.Sin(counter[drawType]) * magnitude + startPosition.y;
					break;
				case "Spiral":
					drawType = 3;
					arrayStart[drawType] = maxInstancesPerDraw * 3 + 1;
					xPosition[drawType] = Mathf.Cos(counter[drawType]) * magnitude * counter[drawType] / 100f + startPosition.y + 5f;
					yPosition = Mathf.Sin(counter[drawType]) * magnitude * counter[drawType] / 100f + startPosition.y;
					break;
			}
		}

			
		if(counter[drawType] < maxInstancesPerDraw - 1)
		{
			instanceOfPixel[arrayStart[drawType] + counter[drawType]] = Instantiate(pixelPrefab, transform.position, Quaternion.identity);
			
			instanceOfPixel[arrayStart[drawType] + counter[drawType]].transform.localScale = new Vector3(pixelSize, pixelSize, 1f);

			spriteScript = instanceOfPixel[arrayStart[drawType] + counter[drawType]].GetComponent<SpriteScript>();
			spriteScript.spritePosition = new Vector3(xPosition[drawType], yPosition, 0f);
			
			spriteScript.drawType = type;
			spriteScript.speed = speed;
			spriteScript.length = length;
			spriteScript.magnitude = magnitude;
			spriteScript.pixelSize = pixelSize;
			
			numberOfPixels[drawType]++;

			counter[drawType]++;
		}
		 
	}
		void RefreshScreen()
		{
			for (int i = 0; i < maxInstancesPerDraw * 4; i++)
			{
				if (instanceOfPixel[i])
				{
					Destroy (instanceOfPixel[i], 0f);
				}
				
			}
			for (int k = 0; k < 4; k++)
			{
			counter[k] = 1;
			xPosition[k] = startPosition.x;
			numberOfPixels[k] = 0;

			}
		}
		
	
	float Randomize()
	{
		float randomColor = Random.Range(1f, 1000f) / 1000f;
		return randomColor;
	}
	
	void KeyReader()
	{
		var inputKey = Input.inputString;
		switch(inputKey)
		{
			case "1":
				sinusMagnitude -= 0.2f;
				sinusMagnitude = Mathf.Clamp(sinusMagnitude, 0.4f, 2f);
				RefreshScreen();
				break;
			case "2":
				sinusMagnitude += 0.2f;
				sinusMagnitude = Mathf.Clamp(sinusMagnitude, 0.4f, 2f);
				RefreshScreen();
				break;
			case "3":
				sinusLength -= 0.2f;
				sinusLength = Mathf.Clamp(sinusLength, 0.4f, 2f);
				RefreshScreen();
				break;
			case "4":
				sinusLength += 0.2f;
				sinusLength = Mathf.Clamp(sinusLength, 0.4f, 2f);
				RefreshScreen();
				break;
			case "5":
				cosinusMagnitude -= 0.2f;
				cosinusMagnitude = Mathf.Clamp(cosinusMagnitude, 0.4f, 2f);
				RefreshScreen();
				break;
			case "6":
				cosinusMagnitude += 0.2f;
				cosinusMagnitude = Mathf.Clamp(cosinusMagnitude, 0.4f, 2f);
				RefreshScreen();
				break;
			case "7":
				cosinusLength -= 0.2f;
				cosinusLength = Mathf.Clamp(cosinusLength, 0.4f, 2f);
				RefreshScreen();
				break;
			case "8":
				cosinusLength += 0.2f;
				cosinusLength = Mathf.Clamp(cosinusLength, 0.4f, 2f);
				RefreshScreen();
				break;
			case "9":
				speed -= 0.005f;
				speed = Mathf.Clamp(speed, 0.005f, 0.2f);
				RefreshScreen();
				break;
			case "0":
				speed += 0.005f;
				speed = Mathf.Clamp(speed, 0.005f, 0.2f);
				RefreshScreen();
				break;
			case "q":
				setpixelSize -= 0.5f;
				setpixelSize = Mathf.Clamp(setpixelSize, 2f, 20f);
				RefreshScreen();
				break;
			case "w":
				setpixelSize += 0.5f;
				setpixelSize = Mathf.Clamp(setpixelSize, 2f, 20f);
				RefreshScreen();
				break;
			case "a":
				cicleRadius -= 0.1f;
				cicleRadius = Mathf.Clamp(cicleRadius, 0.4f, 2f);
				RefreshScreen();
				break;
			case "s":
				cicleRadius += 0.1f;
				cicleRadius = Mathf.Clamp(cicleRadius, 0.4f, 2f);
				RefreshScreen();
				break;
		}
	}
}
