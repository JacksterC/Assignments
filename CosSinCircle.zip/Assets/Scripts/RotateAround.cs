using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateAround : MonoBehaviour
{
    float rotateAngle;
    Vector3 rotateAxis = new Vector3(1f, 1f, 1f), centerPosition;
    InstantiatePixels3D instantiatePixels3Dscript;

    void Start()
    {
        instantiatePixels3Dscript = GameObject.FindObjectOfType(typeof(InstantiatePixels3D)) as InstantiatePixels3D;
        centerPosition = Camera.main.transform.position + new Vector3(0f, 0f, 20f);
        rotateAngle = instantiatePixels3Dscript.pixelRotateSpeed;
    }

    void Update()
    {
        transform.RotateAround(centerPosition, rotateAxis, rotateAngle);
        transform.rotation = Quaternion.Euler(0, 0, 0);
    }
}
