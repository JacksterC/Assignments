using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DrawCircle : MonoBehaviour
{
	InstantiatePixels instantiatePixelsScript;
	Vector3 circleCenterPosition;
	Vector3 nextPosition = new Vector3();
	
	public int instanceSequenceNumber;

	float distanceToNextPixel, counter, counterTwoX, counterTwoY, variableXRadius = 1f, variableYRadius = 1f;
	bool shrinking = false;
	
    void Start()
    {
		QualitySettings.vSyncCount = 0;
		Application.targetFrameRate = 60;
		
		instantiatePixelsScript = GameObject.FindObjectOfType(typeof(InstantiatePixels)) as InstantiatePixels;
		circleCenterPosition = new Vector3(0f, 0f, 0f);
		counter = 1f; counterTwoX = 0f; counterTwoY = 0f;

    }

    void Update()
    {
		SpinAroundCircle();
	}
	
	void MovePixelInCircle(float xRadius, float yRadius)
	{
		distanceToNextPixel = instantiatePixelsScript.circleRadius * Mathf.Cos(Mathf.Deg2Rad * instantiatePixelsScript.degreeAngleBetweenPixels / 2f) * 2f;

		nextPosition.x = Mathf.Sin(Mathf.Deg2Rad * instantiatePixelsScript.degreeAngleBetweenPixels * instanceSequenceNumber + Mathf.Deg2Rad * counter * instantiatePixelsScript.pixelRotateSpeed) * distanceToNextPixel * xRadius;
		nextPosition.y = Mathf.Cos(Mathf.Deg2Rad * instantiatePixelsScript.degreeAngleBetweenPixels * instanceSequenceNumber + Mathf.Deg2Rad * counter * instantiatePixelsScript.pixelRotateSpeed) * distanceToNextPixel * yRadius;

		transform.position = circleCenterPosition + nextPosition;
		counter++;
	}
	
	void SpinAroundCircle()
	{
		if (!shrinking && counterTwoX <= 360f)
		{
		variableXRadius = Mathf.Cos(Mathf.Deg2Rad * counterTwoX);
		counterTwoX += 0.5f;
		} else {
			shrinking = true;
		}
		
		if (shrinking && counterTwoY <= 360f)
		{
		variableYRadius = Mathf.Cos(Mathf.Deg2Rad * counterTwoY);
		counterTwoY += 0.5f;
		} else if ( counterTwoX > 360f && counterTwoY > 360f)
		{
			shrinking = false;
			counterTwoX = 0f;
			counterTwoY= 0f;
		}
		
		MovePixelInCircle(variableXRadius, variableYRadius);
	}
}
