using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InstantiatePixels3D : MonoBehaviour
{
	public GameObject pixelPrefab;
	GameObject[] pixelInstance = new GameObject[101];

	SpriteRenderer pixelSpriteRenderer;

	public bool drawnOnce;
	[Range(0.5f, 5f)]
	public float circleRadius = 1f;
	[Range(0.05f, 0.5f)]
	public float pixelRotateSpeed = 0.1f;
	[Range(3, 100)]
	public int numberOfPixels = 10;
	int maxNumberOfPixs = 100, lastNUmberOfPixels = 1;
	float degreeAngleBetweenPixels, distanceToNextPixel, lastCircleRadius, lastPixelRotateSpeed;

	void Start()
	{
		degreeAngleBetweenPixels = 360f / numberOfPixels;
	}

	void Update()
	{
		if (numberOfPixels != lastNUmberOfPixels || circleRadius != lastCircleRadius || pixelRotateSpeed != lastPixelRotateSpeed)
		{
			drawnOnce = false;
			lastNUmberOfPixels = numberOfPixels;
			lastCircleRadius = circleRadius;
			lastPixelRotateSpeed = pixelRotateSpeed;
		}

		if (!drawnOnce)
		{
			degreeAngleBetweenPixels = 360f / numberOfPixels;
			AddPixels(numberOfPixels);
			drawnOnce = true;
		}
	}

	void AddPixels(int numberOfPixs)
	{
		for (int i = 1; i <= maxNumberOfPixs; i++)
		{
			if (pixelInstance[i])
			{
				Destroy(pixelInstance[i]);
			}
		}

		for (int i = 1; i <= numberOfPixs; i++)
		{
			pixelInstance[i] = Instantiate(pixelPrefab, new Vector3(transform.position.x, transform.position.y, 0f), Quaternion.identity);

			distanceToNextPixel = circleRadius * Mathf.Cos(Mathf.Deg2Rad * degreeAngleBetweenPixels / 2f) * 2f;

			pixelInstance[i].transform.position = new Vector3(Mathf.Sin(Mathf.Deg2Rad * degreeAngleBetweenPixels * i) * distanceToNextPixel, Mathf.Cos(Mathf.Deg2Rad * degreeAngleBetweenPixels * i) * distanceToNextPixel, 0f);

			pixelSpriteRenderer = pixelInstance[i].GetComponent<SpriteRenderer>();
			float colorNuance = (float)i / (float)numberOfPixs;
			pixelSpriteRenderer.color = new Color(colorNuance, 0.5f, colorNuance);

		}
	}
}

