using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InstantiatePixels : MonoBehaviour
{
	public GameObject pixelPrefab;
	GameObject[] pixelInstance = new GameObject [101];
	
	DrawCircle drawCircleScript;
	SpriteRenderer pixelSpriteRenderer;
	
	public bool drawnOnce;
	[Range(0.5f, 5f)]
	public float circleRadius = 1f;
	[Range(0.5f,5f)]
	public float pixelRotateSpeed = 0.5f;
	[Range(1, 100)]
	public int numberOfPixels = 1;
	int maxNumberOfPixs = 100, lastNUmberOfPixels = 1;
	public float degreeAngleBetweenPixels;
	
    void Start()
    {
		degreeAngleBetweenPixels = 360f / numberOfPixels;
    }

    void Update()
    {
		if (numberOfPixels != lastNUmberOfPixels)
		{
			drawnOnce = false;
			lastNUmberOfPixels = numberOfPixels;
		}

		if (!drawnOnce)
		{
			degreeAngleBetweenPixels = 360f / numberOfPixels;
			AddPixels(numberOfPixels);
			drawnOnce = true;
		}
    }
	
	void AddPixels(int numberOfPixs)
	{
		for (int i = 1; i <= maxNumberOfPixs; i++)
		{
			if (pixelInstance[i])
			{
				Destroy (pixelInstance[i]);
			}
		}
	
		for (int i = 1; i <= numberOfPixs; i++)
		{
			pixelInstance[i] = Instantiate(pixelPrefab, new Vector3(transform.position.x, transform.position.y, 0f), Quaternion.identity);

			drawCircleScript = pixelInstance[i].GetComponent<DrawCircle>();
			drawCircleScript.instanceSequenceNumber = i;
			
			pixelSpriteRenderer = pixelInstance[i].GetComponent<SpriteRenderer>();
			float colorNuance = (float)i / (float)numberOfPixs;
			pixelSpriteRenderer.color = new Color(colorNuance, colorNuance, 1f);
			
		}
	}
}

