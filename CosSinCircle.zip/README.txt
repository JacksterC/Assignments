------------Scene Circle------------

Rotating circle of pixels

Adjustable radius, rotation speed and number of pixels in circle

The X/Y circle spin effect is actually just increasing/decreasing X/Y radius :)

Pixels are placed within same circular distance regardless of number of pixels

------------Scene TheOtherStuff------------
 
Sinus and Cosinus curve, Circle based effect, expanding spiral, pixel color effect

Adjustable (all pixels in scene reinstantiated when adjusting)

Pixel size							-	Q to decrease, W to increase
Circle effect- and Spiral radius	-	A to decrease, S to increase
Sinus curve magnitude				-	1 to decrease, 2 to increase
Cosinus curve magnitude				-	5 to decrease, 6 to increase
Sinus curve length					-	3 to decrease, 4 to increase
Cosinus curve length				-	7 to decrease, 8 to increase
Pixel speed							-	9 to decrease, 0 to increase

------------Scene TheSimple3DRotateAround------------

X/Y/Z Spinning circle of pixels using RotateAround

Adjustable radius, rotation speed and number of pixels in circle

Pixels are placed within same circular distance regardless of number of pixels