using UnityEngine;

public class Meteor : MonoBehaviour
{
	public float speed = 1;
    public GameObject split;
    public GameObject Hit;
	public GameObject Explosion;
	public GameObject Gem1;
	public GameObject Score;
	
	public float meteorSpawnTime;
	public float meteorInvulnTime = 0.1f;
	
	public ScoreController scorecontroller;


    void Start()
    {
		//Set a start speed
		GetComponent<Rigidbody2D>().velocity = -transform.up * speed;
		
		meteorSpawnTime = Time.time;
		
    }

	void OnTriggerEnter2D(Collider2D other)
	{
		//bullet hit the asteroid
		if (other.gameObject.CompareTag("Bullet") && Time.time >= meteorSpawnTime + meteorInvulnTime)
		{
			//Spawn hit effect
			Vector3 hitPoint = (other.transform.position + transform.position) / 2;
			var newHit = Instantiate(Hit, hitPoint, Quaternion.identity);
			Destroy(newHit, 0.5f);

			//Remove bullet
			Destroy(other.gameObject);


			//Asteroid was destroyed

			//Spawn new asteroids
			if (split != null)
			{
				Instantiate(split, transform.position, Quaternion.Euler(0, 0, transform.rotation.eulerAngles.z + 30));
				Instantiate(split, transform.position, Quaternion.Euler(0, 0, transform.rotation.eulerAngles.z - 30));
			}

			//Spawn explostion effect
			var newExplosion= Instantiate(Explosion, transform.position, Quaternion.identity);
			Destroy(newExplosion, 0.5f);
			
			int noofGems = Random.Range(1, 4);
			
			for (int x = 1; x <= noofGems; x++)
			{
				var newGem = Instantiate(Gem1, transform.position + new Vector3 (Random.Range(1, 4) * 0.2f, Random.Range(1, 4) * 0.2f, 0), Quaternion.Euler(0, 0, transform.rotation.eulerAngles.z + (x * 10)));
			}
			
			if (gameObject.CompareTag("BigMeteor"))
			{
				scorecontroller.GetComponent<ScoreController> ().AddScore(1000);
			}
			if (gameObject.CompareTag("MediumMeteor"))
			{
				scorecontroller.GetComponent<ScoreController> ().AddScore(1000);
			}
			if (gameObject.CompareTag("SmallMeteor"))
			{
				scorecontroller.GetComponent<ScoreController> ().AddScore(1000);
			}
						//Destroy asteroid
			Destroy(gameObject);
			

		}
	}
}
