using UnityEngine;

public class MeteorSpawner : MonoBehaviour
{
    public GameObject meteor;
    public int amount = 5;
	
	public float meteorSpawnTime;
	public float meteorInvulnTime = 5f;

	float width, height;

    void Start()
	{
		//Get screen size
		width = Camera.main.orthographicSize * Camera.main.aspect;
		height = Camera.main.orthographicSize;

		//Spawn the first wave
		SpawnWave(amount);
	}

	private void SpawnWave(int numberOfAsteroids)
	{
		//Spawn meteors
		for (int i = 0; i < numberOfAsteroids; i++)
		{
			SpawnMeteor();
		}
	}

	private void SpawnMeteor()
	{
		Vector2 randomPosition = new Vector2();
		randomPosition.x = Random.Range(-width, width);
		randomPosition.y = Random.Range(-height, height);

		Quaternion randomRotation = Quaternion.Euler(0, 0, Random.Range(0, 360f));

		Instantiate(meteor, randomPosition, randomRotation, transform);
		meteorSpawnTime = Time.time;
	}
}
